/**
 * Miscellaneous shared enums go here.
 */

export enum NodeEnvs {
  Dev = 'development',
  Staging = 'staging',
  Production = 'production'
}
