import "reflect-metadata";
import { DataSource } from "typeorm";

export const AppDataSource = new DataSource({
    "type": "mysql",
    "host": process.env.DB_HOST,
    "port": Number(process.env.DB_PORT) || 3306,
    "username": process.env.DB_USER,
    "password": process.env.DB_PASSWORD,
    "database": process.env.DB_NAME,
    "entities": ["src/entities/**/*{.ts,.js}"], //yha hamne sare models diye hai models hi hmari enetities hai 
    "synchronize": true,  // yha ham synchronize ko true karenge iski madad se ham typorm ko batayenge ke hamari entities ko db ki table ke sath sync rakho yani ye typeorm entites ko read karega or entities ko dekhte hue db me table create kardega
    "logging": false, // isse me ham logs dekh sakte hai query ke jo bhi typeorm banayega
});

// type orm me hame migration run karne ki zarurat nahi hoti hai q ki hamne synchronize on kar rakha hai jese hi server on hoga typeorm hamari entites ko lekar sari tables create kardega khud hi server strart hote hi 
// Ham jab bhi typeorm ke andar koi bhi enetity register karte hai typeorm uske liye ek repository bana deta hai bydefault
// Ab in repository ki madad se ham object oriented ke patterns ko istemal karte hue kisi bhi data ko insert update delete karwa sak te hai
// typeorm sql khud hi generate karega
// typorm me sare methods aynschornous hote hai async wait use karna hoga try catch ke sath

AppDataSource.initialize()
    .then(() => {
        console.log("Database connection established successfully!");
    })
    .catch((err) => {
        console.error("Error during database connection!", err);
});
