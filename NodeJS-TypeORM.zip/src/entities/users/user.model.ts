import { Entity, PrimaryGeneratedColumn, Column } from "typeorm"

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;
  @Column()
  username: string;
  @Column({ unique: true })
  email: string;
  @Column({select: false})
  password: string;
  @Column()
  dob: string;
  @Column()
  profileImg: string;
}
// enetity decorator hamari is user class ko db ki table ke sath map kardega
