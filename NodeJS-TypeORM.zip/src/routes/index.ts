import express, { Router } from 'express';
import userRoutes from './user.routes';
// import commentRoutes from './comment.routes';
// import postRoutes from './posts.routes';

const router: Router = express.Router();

// Use the user routes
router.use('/users', userRoutes);
// router.use('/comment', commentRoutes);
// router.use('/post', postRoutes);

// Export the router
export default router;
