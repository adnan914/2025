const config = {
  API_URL: "https://pangea-interview-fastapi-proxy-uljcog6taq-ue.a.run.app"
}
export default config