import { ReactElement } from "react";

export type BoxProps = {
  children: ReactElement;
};

export type MultiSelect = {
  name: string;
  value: any;
};
