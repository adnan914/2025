const ComponentLoader = () => {
  return (
    <div className="linear-activity">
      <div className="indeterminate"></div>
    </div>
  );
};
export default ComponentLoader;
