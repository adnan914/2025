'use strict';

const fs = require('fs');
const path = require('path');
const basename = path.basename(__filename);
const Sequelize = require("sequelize");
const sequelize = require('../config/sequelize');   
const db = {};

const files = fs.readdirSync(__dirname);
for (let file of files) {
  if (basename === file) continue;
  const subFiles = fs.readdirSync(`${__dirname}/${file}`);
  for (let f of subFiles) {
    if (
      f.indexOf('.') !== 0 &&
      f.slice(-3) === '.js' &&
      f.indexOf('.test.js') === -1
    ) {
      const model = require(path.join(__dirname, `/${file}/${f}`))(sequelize, Sequelize.DataTypes);
      db[model.name] = model;
    }
  }
}

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
