'use strict';
module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    username: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    dob: DataTypes.STRING,
    profileImg: DataTypes.STRING
  }, {
    defaultScope: {
      attributes: { exclude: ['password'] }, // Exclude password by default
    },
    scopes: {
      withPassword: { attributes: {} }, // Scope to include password if needed
    },
  });
  User.associate = function (models) {
    // associations can be defined here
    User.hasOne(sequelize.define('Address'));
    User.hasMany(sequelize.define('Post'));
  };
  return User;
};



// Usage
// With this setup, by default, Sequelize will exclude password from the query:

// javascript
// Copy code
// const users = await User.findAll(); // `password` will be excluded
// If you need to include password, you can use the withPassword scope:

// javascript
// Copy code
// const usersWithPassword = await User.scope('withPassword').findAll();