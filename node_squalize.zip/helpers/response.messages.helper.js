const resMessage = {
  LOGIN: 'Login successfully',
  LOGIN_FAILED: 'Login failed',
  INVALID_TOKEN: 'Invalid token',
  INVALID_CRED: 'Invalid credentials',
  NOT_PROVIDED_TOKEN: "Token not provded",
  INVALID_ID: "Invalid user id",
  SERVER_ERROR: 'There was an error',
  DATA_FOUND: 'Data found',
  NO_DATA_FOUND: 'No data found',
  ADD_SUCCESS: 'Add successfully',
  REGISTRATION: 'Registration Successfully!',
  REGISTRATION_ERROR: 'There was an error in registration!',
  EMAIL_EXIST: 'Email already exists, choose another email!',
  TOKEN_NOT_PROVIDED: 'Token not provided!',
  UPDATE_SUCC: 'Update successfully!',
  DELETE_SUCC: 'Delete successfully!',
  UPDATE_FAILED: 'There was an error in update',
  DELETE_FAILED: 'There was an error in delete',
  CHOOSE_ANOTHER_PASS: 'Choose another password',
  CREATE_COMMENT: "Comment created successfully",
  WRONG: "Something went wrong"
};

module.exports = resMessage;