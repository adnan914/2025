const jwt = require('jsonwebtoken');

const generateToken = (data, secret, expTime) => {
    return jwt.sign(data, secret, expTime);
}
module.exports = {
    generateToken
}