const models = require('../models');
const resMessage = require('../helpers/response.messages.helper');

const create = async (req, res) => {
    try {
        const category = await models.Category.findByPk(req.body.categoryId);
        if (!category) {
            return res.status(400).json({
                message: resMessage.INVALID_ID
            });
        }

        const createdPost = await models.Post.create(req.body);
        res.status(201).json({
            message: resMessage.ADD_SUCCESS,
            post: createdPost
        });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error: error
        });
    }
};

const getPost = async (req, res) => {
    const id = req.params.id;

    try {
        const post = await models.Post.findByPk(id, {
            include: [models.Category, models.User]
        });

        if (post) {
            res.status(200).json(post);
        } else {
            res.status(404).json({
                message: resMessage.NO_DATA_FOUND
            });
        }
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG
        });
    }
};

const postList = async (req, res) => {
    try {
        const posts = await models.Post.findAll();
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG
        });
    }
};

const updatePost = async (req, res) => {

    try {
        const category = await models.Category.findByPk(req.body.categorId);
        if (!category) {
            return res.status(400).json({
                message: resMessage.INVALID_ID
            });
        }

        await models.Post.update(req.body, { where: { id: req.params.id, userId: req.body.userId } });
        res.status(200).json({
            message: resMessage.UPDATE_SUCC,
            post: updatedPost
        });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error: error
        });
    }
};

const deletePost = async (req, res) => {
        try {
        await models.Post.destroy({ where: { id: req.params.id, userId: req.body.userId } });
        res.status(200).json({
            message: resMessage.DELETE_SUCC
        });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error: error
        });
    }
};

module.exports = {
    create,
    getPost,
    postList,
    updatePost,
    deletePost
};
