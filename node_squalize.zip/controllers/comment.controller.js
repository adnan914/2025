const models = require('../models');
const resMessage = require('../helpers/response.messages.helper');


const create = async (req, res) => {

    try {
        const post = await models.Post.findByPk(req.body.postId);
        if (!post) {
            return res.status(404).json({ message: resMessage.NO_DATA_FOUND });
        }
        const result = await models.Comment.create(req.body);
        res.status(201).json({
            message: resMessage.CREATE_COMMENT, comment: result
        });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error
        });
    }
};

const getComment = async (req, res) => {
    try {
        const result = await models.Comment.findByPk(req.params.id);
        if (result) {
            res.status(200).json(result);
        } else {
            res.status(404).json({ message: resMessage.DATA_FOUND });
        }
    } catch (error) {
        res.status(500).json({ message: resMessage.WRONG });
    }
};

const commentList = async (req, res) => {
    try {
        const result = await models.Comment.findAll();
        res.status(200).json(result);
    } catch (error) {
        res.status(500).json({ message: resMessage.WRONG });
    }
};

const updateComment = async (req, res) => {
    const id = req.params.id;
    const updatedComment = { content: req.body.content };
    const userId = req.body.userId;

    try {
        await models.Comment.update(updatedComment, { where: { id, userId } });
        res.status(200).json({
            message: resMessage.UPDATE_SUCC,
            post: updatedComment
        });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error
        });
    }
};

const deleteComment = async (req, res) => {
    const id = req.params.id;
    const userId = req.body.userId;

    try {
        await models.Comment.destroy({ where: { id, userId } });
        res.status(200).json({ message: resMessage.DELETE_SUCC });
    } catch (error) {
        res.status(500).json({
            message: resMessage.WRONG,
            error
        });
    }
};

module.exports = {
    create,
    getComment,
    commentList,
    updateComment,
    deleteComment
};
