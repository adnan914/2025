const bcryptjs = require('bcryptjs');
const { User } = require("../models");
const resMessage = require('../helpers/response.messages.helper');
const commonFun = require('../helpers/common.functions.helper');

const createUser = async (req, res) => {
    try {
        console.log('name', req.body)
        const isEmailExist = await User.findOne({ where: { email: req.body.email } });
        // 409 Conflict
        if (isEmailExist) return res.status(409).json({ success: false, message: resMessage.EMAIL_EXIST });
        req.body.password = await bcryptjs.hash(req.body.password, 10);
        const userDetails = await User.create(req.body);
        delete userDetails.password;
        res.status(201).json({ success: true, message: resMessage.USER_CREATE, data: userDetails });
    } catch (error) {
        res.status(500).json({ success: false, message: resMessage.SERVER_ERROR, error: error.message });
    }
};
const loginUser = async (req, res) => {
    try {
        const isEmailExist = await User.scope('withPassword').findOne({ where: { email: req.body.email } });
        // 401 Unauthorized

        if (!isEmailExist) return res.status(401).json({ success: false, message: resMessage.INVALID_CRED });
        const isPasswordMatch = await bcryptjs.compare(req.body.password, isEmailExist.password);
        // 401 Unauthorized
        if (!isPasswordMatch) return res.status(401).json({ success: false, message: resMessage.INVALID_CRED });
        const userData = { ...isEmailExist.dataValues };
        delete userData.password
        // delete userData.password;
        const token = commonFun.generateToken(userData, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRATION });
        const refreshToken = commonFun.generateToken(userData, process.env.JWT_SECRET, { expiresIn: process.env.JWT_REFRESH_EXPIRATION });
        res.status(200).json({ success: true, message: resMessage.LOGIN, data: { ...userData, token, refreshToken } });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: resMessage.LOGIN_FAILED, error: error.message });
    }
};

const listUser = async (req, res) => {
    try {
        const userList = await User.findAll();
        res.status(200).json({ success: true, message: resMessage.DATA_FOUND, data: userList });
    } catch (error) {
        res.status(500).json({ success: false, message: resMessage.SERVER_ERROR, error: error.message });
    }
};

const getUser = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        // 404 Not Found
        if (!user) return res.status(404).json({ success: false, message: resMessage.NO_DATA_FOUND });
        res.status(200).json({ success: true, message: resMessage.DATA_FOUND, data: user });
    } catch (error) {
        res.status(500).json({ success: false, message: resMessage.SERVER_ERROR, error: error.message });
    }
};
const updateUser = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        // 404 Not Found
        if (!user) return res.status(404).json({ success: false, message: resMessage.INVALID_ID });
        if (req.file) req.body.profileImg = req.file.filename;
        await user.update(req.body);
        res.status(200).json({ success: true, message: resMessage.UPDATE_SUCC });
    } catch (error) {
        res.status(500).json({ success: false, message: resMessage.UPDATE_FAILED, error: error.message });
    }
};
const deleteUser = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        // 404 Not Found
        if (!user) return res.status(404).json({ success: false, message: resMessage.INVALID_ID });
        await user.destroy();
        res.status(200).json({ success: true, message: resMessage.DELETE_SUCC });
    } catch (error) {
        res.status(500).json({ success: false, message: resMessage.DELETE_FAILED, error: error.message });
    }
};
module.exports = {
    createUser,
    listUser,
    getUser,
    updateUser,
    deleteUser,
    loginUser
}