require('dotenv').config({ path: `.env.${process.env.NODE_ENV}` });
const express = require('express');
const app = express();
const routes = require('./routes');

// Middleware setup (if needed)
app.use(express.json());
app.use(express.static(__dirname + '/public'));

app.use('/v1', routes)

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
