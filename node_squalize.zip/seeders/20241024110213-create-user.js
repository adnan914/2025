'use strict';

const userData = [
  {
    username: 'Adnan Qureshi1',
    email: 'adnan@bitcot.com',
    password: '123456',
    dob: '04-12-1990'
  },
  {
    username: 'Adnan Qureshi2',
    email: 'adnan1@bitcot.com',
    password: 'asdasdadasdasd',
    dob: '04-12-1990'
  },
  {
    username: 'Adnan Qureshi3',
    email: 'adnan2@bitcot.com',
    password: 'asdasdadasdasd',
    dob: '04-12-1990'
  },
  {
    username: 'Adnan Qureshi4',
    email: 'adnan3@bitcot.com',
    password: 'asdasdadasdasd',
    dob: '04-12-1990'
  },
  {
    username: 'Adnan Qureshi5',
    email: 'adnan4@bitcot.com',
    password: 'asdasdadasdasd',
    dob: '04-12-1990'
  }
];

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Users', userData, {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Users', null, {});
  }
};