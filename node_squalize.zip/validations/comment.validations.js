const Joi = require('joi');

const validateCreateCommentSchema = (req, res, next) => {
    const { error } = Joi.object({
        content: Joi.string().required(),
        postId: Joi.string().required(),
        userId: Joi.number().required()
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validateCommentIdSchema = (req, res, next) => {
    const { error } = Joi.object({
        id: Joi.number().required()
    }).validate(req.params);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validateUserIdSchema = (req, res, next) => {
    const { error } = Joi.object({
        userId: Joi.number().required()
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validateUpdateCommentSchema = (req, res, next) => {
    const { error } = Joi.object({
        content: Joi.string(),
        postId: Joi.string().required(),
        userId: Joi.number().required()
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

module.exports = {
    validateUserIdSchema,
    validateCommentIdSchema,
    validateUpdateCommentSchema,
    validateCreateCommentSchema
}