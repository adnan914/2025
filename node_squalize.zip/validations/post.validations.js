const Joi = require('joi');


const validateCreatePostSchema = (req, res, next) => {
    const { error } = Joi.object({
        title: Joi.string().required(),
        content: Joi.string().required(),
        imageUrl: Joi.string().required(),
        categoryId: Joi.number().required(),
        userId: Joi.number().required()
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validatePostIdSchema = (req, res, next) => {
    const { error } = Joi.object({
        id: Joi.number().required()
    }).validate(req.params);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validateCateogryIdSchema = (req, res, next) => {
    const { error } = Joi.object({
        categoryId: Joi.number().required(),
        userId: Joi.number().required()    
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    
    next();
};

const validateUserIdSchema = (req, res, next) => {
    const { error } = Joi.object({
        userId: Joi.number().required()
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

const validateUpdatePostSchema = (req, res, next) => {
    const { error } = Joi.object({
        title: Joi.string(),
        content: Joi.string(),
        imageUrl: Joi.string(),
    }).validate(req.body);
    if (error) {
        return res.status(400).json({ message: error.message, details: error.details });
    }
    next();
};

module.exports = {
    validateCreatePostSchema,
    validatePostIdSchema,
    validateUpdatePostSchema,
    validateUserIdSchema,
    validateCateogryIdSchema
}