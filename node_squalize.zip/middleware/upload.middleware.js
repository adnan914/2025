const multer = require("multer");
const imagesPath = './public/images/';
const pdfPath = './public/pdf/';

const imageStorage = multer.diskStorage({
    destination: (req, file, callback) => {
        console.log("imagesPath", imagesPath, file)
        callback(null, imagesPath)
    },
    filename: (req, file, callback) => {
        const timestamp = Date.now();
        const randomNum = Math.round(Math.random() * 1E9)
        callback(null, `Profile_${timestamp}-${randomNum}-${file.originalname}`);
    }
});
const pdfStorage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, pdfPath)
    },
    filename: (req, file, callback) => {
        const timestamp = Date.now();
        const randomNum = Math.round(Math.random() * 1E9)
        callback(null, `Profile_${timestamp}-${randomNum}-${file.originalname}`);
    }
});

const uploadImage = multer({ storage: imageStorage });
const uploadPDF = multer({ storage: pdfStorage });

module.exports = {
    uploadImage,
    uploadPDF
}