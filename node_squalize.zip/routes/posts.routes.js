const express = require('express');
const router = express.Router();
const postsController = require('../controllers/post.controller');
const { verifyToken } = require('../middleware/verify.token.middleware');
const { validateCreatePostSchema, validateUpdatePostSchema, validatePostIdSchema, validateCateogryIdSchema, validateUserIdSchema } = require('../validations/post.validations');


router.post("/create", verifyToken, validateCreatePostSchema, postsController.create);
router.get("/list", verifyToken, postsController.postList);
router.get("post/:id", verifyToken, validatePostIdSchema, postsController.getPost);
router.patch("update/:id", verifyToken, validateUpdatePostSchema, validateCateogryIdSchema, postsController.updatePost);
router.delete("delete/:id", verifyToken, validatePostIdSchema, validateUserIdSchema, postsController.deletePost);

module.exports = router;
