const express = require('express');
const commentController = require('../controllers/comment.controller');
const { verifyToken } = require('../middleware/verify.token.middleware');
const { validateCommentIdSchema, validateUpdateCommentSchema, validateCreateCommentSchema, validateUserIdSchema } = require('../validations/comment.validations');

const router = express.Router();

router.post("/create", verifyToken, validateCreateCommentSchema, commentController.create);
router.get("/list", verifyToken, commentController.commentList);
router.get("comment/:id", verifyToken, validateCommentIdSchema, commentController.getComment);
router.patch("update/:id", verifyToken, validateCommentIdSchema, validateUpdateCommentSchema, commentController.updateComment);
router.delete("delete/:id", verifyToken, validateCommentIdSchema, validateUserIdSchema, commentController.deleteComment);

module.exports = router;
