export const API_ROUTES = {
  LOGOUT_API: '',
  PHOTOS_API: '/users',
  USER_API: '/users',
}


const AUTH_ROUTES = {
  USER_PATH: '/users',
  LOGIN_PATH: '/login'
}

const PRIVATE_ROUTES = {
  DASHBOARD_PATH: '/dashboard',
  DEBOUNCE_PATH: '/debounce',
}

export const ROUTES = {
  ...AUTH_ROUTES,
  ...PRIVATE_ROUTES
}

export const listLimit = 10