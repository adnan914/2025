import config from "config.js";
import axios from 'axios';

const instance = axios.create({
  baseURL: config.API_URL
});

export default instance;