import React from 'react'
import { Navigate } from 'react-router-dom'
import Header from 'components/shared/header'
import { useSelector } from 'react-redux'
import { ROUTES } from 'utils/constant'

export const PrivateLayout = ({ children }) => {
  const { token } = "duudkkjd"
  // const { isSideBar, isToggleSideBar } = useSelector(state => state.layout)

  const { history } = children.props
  if(!token) {
    return (
      <div id="wrapper">
        <Header history={history} />
        <div className="bt_table_main_wrapper">{children}</div>
      </div>
    )
  }
  return (
    <Navigate to={ROUTES.LOGIN_PATH} replace />
  )
}

export const AuthLayout = ({ children }) => {
  const { token } = "duudkkjd"
  
  if(!token) {
    return (
      <div id="wrapper">
        {children}
      </div>
    )
  }
  return (
    <Navigate to={ROUTES.DASHBOARD_PATH} replace />
  )
}