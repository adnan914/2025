import React from 'react'
import { Routes, Route, Navigate, BrowserRouter as Router } from 'react-router-dom'
import { createBrowserHistory as createHistory } from 'history'
import { Provider } from 'react-redux'
import { authRoutes, privateRoutes } from './routerConfig'
import Loader from 'components/shared/loader/Loader'
import ConfirmDialog from 'components/shared/common-dialog'

import CssBaseline from '@mui/material/CssBaseline';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { red } from '@mui/material/colors';

import store from 'redux/store/store'
import { ROUTES } from 'utils/constant'

const theme = createTheme({
  palette: {
    primary: {
      main: '#556cd6',
    },
    secondary: {
      main: '#19857b',
    },
    error: {
      main: red.A400,
    },
  },
});

const Main = () => {
  const history = createHistory()
  history.listen(_=> {
    window.scrollTo(0,0)
  })

  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Loader />
        <ConfirmDialog />
        <Router>
          <Routes>
            {authRoutes.map(({ layout: AuthLayout, component: Component, ...restProps }) => (
              <Route 
                {...restProps}
                element={
                  <AuthLayout>
                    <Component {...history} />
                  </AuthLayout>
                }
              />
            ))}
            {privateRoutes.map(({ layout: PrivateLayout, component: Component, ...restProps }) => (
              <Route 
                {...restProps}
                element={
                  <PrivateLayout>
                    <Component history={history} />
                  </PrivateLayout>
                }
              />
            ))}
            <Route path='*' element={ <Navigate replace to={ROUTES.USER_PATH} /> } />
          </Routes>
        </Router>
      </ThemeProvider>
    </Provider>
  )
}

export default Main