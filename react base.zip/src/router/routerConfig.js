import { ROUTES } from 'utils/constant'
import { PrivateLayout, AuthLayout } from './routerLayout'

import Dashboard from 'pages/Dashboard'
import Login from 'pages/Login'
import Debounce from 'pages/Debounce'
import Users from 'pages/Users'

export const authRoutes = [
  {
    key: 'Login',
    path: ROUTES.LOGIN_PATH,
    component: Login,
    exact: true,
    layout: AuthLayout
  }
]

export const privateRoutes = [
  {
    key: 'Dashboard',
    path: ROUTES.DASHBOARD_PATH,
    component: Dashboard,
    exact: true,
    layout: PrivateLayout
  },
  {
    key: 'Debounce',
    path: ROUTES.DEBOUNCE_PATH,
    component: Debounce,
    exact: true,
    layout: PrivateLayout
  },
  {
    key: 'Users',
    path: ROUTES.USER_PATH,
    component: Users,
    exact: true,
    layout: PrivateLayout
  }
]