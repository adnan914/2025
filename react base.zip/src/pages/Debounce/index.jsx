/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useCallback  } from 'react'

const Debounce = () => {

    const [ search, setSearch ] = useState([])

    const debounce = (func) => {
        let timer;
        return function (...args) {
            const context = this;
            if(timer) clearTimeout(timer)
            timer = setTimeout(() => {
                timer= null
                func.apply(context, args)
            }, 500);
        }
    }

    const handleChange = ({ target }) => {
        fetch(`https://demo.dataverse.org/api/search?q=${target.value}`)
        .then(res => res.json())
        .then(res => {
            setSearch(res.data.items)
        })
    }

    const optimiseVersion = useCallback(debounce(handleChange))

    return (
        <div className='App'>
            <input type="text" placeholder='Enter Something...' className='search' onChange={optimiseVersion} />
            {search.length ? 
            <div className='autocomplete'>
                {search.map((item, i) => (
                    <div className='autocompleteItems' key={i}>
                        {item.name}
                    </div>
                ))}
            </div>
            : null}
        </div>
    )
}

export default Debounce