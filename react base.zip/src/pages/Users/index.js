import React, { useState, useEffect } from 'react'

import { listLimit } from 'utils/constant'
import UsersTable from './UsersTable'
import { getUser } from 'redux/action';
import { useDispatch, useSelector } from 'react-redux';

const Users = () => {
  const dispatch= useDispatch()
  // const userList = useSelector((state) => state.userReducer)
  const {userList, total} = useSelector((state) => state?.userReducer)
console.log(userList, "userList")
  const defaultPagination = {
    page: 1,
    limit: listLimit,
    order: "",
    sort: "",
    filterBy: "",
    username: ""
  }

  const [pagination, setPagination] = useState(defaultPagination)
  const [searchFilter, setSearchFilter] = useState("");

  useEffect(() => {
    dispatch(getUser())
  }, [])
  

  const setPage = (page) => {
    setPagination({ ...pagination, page });
  };

  const setSorting = (order, sort) => {
    setPagination({ ...pagination, order, sort, page: 1 });
  }

  // const handleLimit = (e) => {
  //     setPagination({ ...pagination, limit: e.target.value });
  // }

  const setFilterBy = (value) => {
    setPagination({ ...pagination, filterBy: value, page: 1 })
  }

  const handleAdd = () => {
    console.log("Add Button");
  }

  const handleSearchFilter = (value) => {
    setSearchFilter(value)
    if (!value.length || value.length > 2) {
      setPagination({ ...pagination, username: value, page: 1 })
    }
  }

  return (
    <div className='table-box'>
      <UsersTable
        totalCount={total}
        pagination={pagination}
        setPagination={setPage}
        data={userList}
        setSorting={setSorting}
        setFilterBy={setFilterBy}
        handleAdd={handleAdd}
        searchFilter={searchFilter}
        handleSearchFilter={handleSearchFilter}
      ></UsersTable>
    </div>
  )
}

export default Users