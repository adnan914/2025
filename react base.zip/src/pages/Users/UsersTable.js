import React, { useState, useEffect, useCallback } from "react";
import CommonTable from "components/shared/common-table/CommonTable";
import Sorting from "components/shared/common-table/Sorting";
import Grid3x3Icon from "@mui/icons-material/Grid3x3";
import LanguageIcon from "@mui/icons-material/Language";
import {
  PersonOutlined,
  LocalPostOfficeOutlined,
  LocalPhoneOutlined,
  ApartmentOutlined,
  FormatListBulleted,
} from "@mui/icons-material";

const UsersTable = ({
  totalCount,
  pagination,
  setPagination,
  data,
  setSorting,
  setFilterBy,
  handleAdd,
  handleSearchFilter,
  searchFilter,
}) => {
  const [userData, setUserData] = useState([]);
  const keys = [
    <Sorting titleIcon={<Grid3x3Icon fontSize="small" />} title="Avatar" />,
    <Sorting
      titleIcon={<PersonOutlined fontSize="small" />}
      title="firstName"
      setSorting={setSorting}
      sortList={[
        { icon: <FormatListBulleted />, text: "Sort A → Z", order: "ASC" },
        { icon: <FormatListBulleted />, text: "Sort Z → A", order: "DESC" },
      ]}
      sortBy="FirstName"
    />,
    <Sorting
      titleIcon={<PersonOutlined fontSize="small" />}
      title="Username"
    />,
    <Sorting
      titleIcon={<LocalPostOfficeOutlined fontSize="small" />}
      title="Email"
    />,
    <Sorting titleIcon={<LanguageIcon fontSize="small" />} title="domain" />,
    <Sorting
      titleIcon={<LocalPhoneOutlined fontSize="small" />}
      title="Phone"
    />,
    <Sorting
      titleIcon={<ApartmentOutlined fontSize="small" />}
      title="Company Name"
    />,
  ];

  const filterBy = [
    {
      text: "Name",
      value: "name",
    },
    {
      text: "Username",
      value: "username",
    },
    {
      text: "Email",
      value: "email",
    },
  ];

  const userTableData = useCallback(() => {
    if (data?.length) {
      return data?.map((item) => {
        return {
          "Avatar":<><img src={item.image} alt="" style={{width:"30%"}} /></> ,
          "firstName": item.firstName,
          "Username": item.username,
          "Email": item.email ? item.email : "-",
          "domain": item.domain ? item.domain : "-",
          "Phone": item.phone ? item.phone : "-",
          "Company Name": item.company ? item.company.name : "-",
        };
      });
    } else {
      return [];
    }
  }, [data]);

  useEffect(() => {
    let userRowData = userTableData(data);
    if (JSON.stringify(userRowData) !== JSON.stringify(userData)) {
      setUserData(userRowData);
    }
  }, [userTableData, data, userData]);

  return (
    <CommonTable
      totalCount={totalCount}
      customPagination={pagination}
      setCustomPagination={setPagination}
      data={userData}
      keys={keys}
      // filterBy={filterBy}
      // setFilterBy={setFilterBy}
      AddButton="Add New User"
      handleAdd={handleAdd}
      searchFilter={searchFilter}
      setSearchFilter={handleSearchFilter}
      isHideField={false}
    />
  );
};

export default UsersTable;
