/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect  } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getPhotos } from "redux/action"
import { listLimit } from 'utils/constant'
import PhotoTable from './PhotoTable'
// import Breadcrumb from 'components/breadcrumb'
// import HomeIcon from '@mui/icons-material/Home';

const Home = () => {
    const dispatch = useDispatch()
    const { photosList, count } = useSelector(state => state.jsonPlaceholderReducer)
    
    const defaultPagination = {
        page: 1,
        limit: listLimit,
        order: "",
        sort: "",
        filterBy: "",
        username: ""
    }

    const [pagination, setPagination] = useState(defaultPagination)
    const [searchFilter, setSearchFilter] = useState("");

    useEffect (() => {
        dispatch(getPhotos(pagination))
    },[pagination])

    const setPage = (page) => {
        setPagination({ ...pagination, page });
    };

    const setSorting = (order, sort) => {
        setPagination({ ...pagination, order, sort, page: 1 });
    }

    // const handleLimit = (e) => {
    //     setPagination({ ...pagination, limit: e.target.value });
    // }

    const setFilterBy = (value) => {
        setPagination({...pagination, filterBy: value, page: 1})
    }

    const handleAdd = () => {
        console.log("Add Button");
    }

    const handleSearchFilter = (value) => {
      setSearchFilter(value)
      if(!value.length || value.length > 2) {
        setPagination({...pagination, username: value, page: 1})
      }
    }

    return (
            <div className='table-box'>
                <PhotoTable
                    totalCount={count}
                    pagination={pagination}
                    setPagination={setPage}
                    data={photosList}
                    setSorting={setSorting}
                    setFilterBy={setFilterBy}
                    handleAdd={handleAdd}
                    searchFilter={searchFilter}
                    handleSearchFilter={handleSearchFilter}
                ></PhotoTable>
            </div>
    )
}

export default Home