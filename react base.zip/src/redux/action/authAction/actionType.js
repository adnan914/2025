const actionType = {
    LOGIN: 'LOGIN',
    LOGOUT: 'LOGOUT'
}

export default actionType