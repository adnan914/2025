import actionType from './actionType'
import * as commonService from 'utils/CommonService'
import * as API from 'api/authApi'

export const logout = () => async dispatch => {
    commonService.isLoading.onNext(true);
    const res = await API.logout()
    if(!res.error) {
        dispatch({
            type: actionType.LOGOUT,
            payload: res
        })
        localStorage.removeItem('user')
        localStorage.removeItem('token')
    }
    commonService.isLoading.onNext(false);
}