const actionType = {
    PHOTOS: "PHOTOS"
}

export default actionType