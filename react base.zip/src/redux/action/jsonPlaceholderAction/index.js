import actionType from './actionType'
import * as commonService from 'utils/CommonService'
import * as API from 'api/jsonPlaceholderApi'

export const getPhotos = (body) => async dispatch => {
    commonService.isLoading.onNext(true);
    let params = {}
    for(const property in body){
        if(body[property]) params = {...params, [`${property}`]: body[property]}
    }
    dispatch({
        type: actionType.PHOTOS,
        payload: await API.getPhotos(params)
    })
    commonService.isLoading.onNext(false);
}