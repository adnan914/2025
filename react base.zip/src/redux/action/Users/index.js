import actionType from './actionType'
import * as commonService from 'utils/CommonService'
import * as API from 'api/usersApi'
import { getUsers } from "redux/store/userSlice"


export const getUser = () => async dispatch => {

  commonService.isLoading.onNext(true);
  const res = await API.getUser()
  dispatch({
    type: "userReducer/getUsers",
    payload: res
  })
  commonService.isLoading.onNext(false);
}