const actionType = {
  GET_USER:"GET_USER",
}

export default actionType