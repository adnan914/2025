export { logout } from "./authAction";
export { setLayout } from "./layoutAction";

export { getPhotos } from "./jsonPlaceholderAction"

export { getUser } from "./Users"
