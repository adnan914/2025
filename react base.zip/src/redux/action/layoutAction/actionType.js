const actionType = {
    TOGGLE_SIDEBAR: "TOGGLE_SIDEBAR"
}

export default actionType