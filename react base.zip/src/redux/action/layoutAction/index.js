import actionType from './actionType'

export const setLayout = (toggle) => async dispatch => {
    dispatch({
        type: actionType.TOGGLE_SIDEBAR,
        payload: toggle
    })
}