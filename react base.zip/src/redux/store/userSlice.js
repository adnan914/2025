import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  userList: [],
  total: 0
}

export const userSlice = createSlice({
  name: 'userReducer',
  initialState,
  reducers: {
    getUsers: (state, action) => {
      state.userList = action.payload.users
      state.total = action.payload.total
      
    },
  },
})

export const { getUsers } = userSlice?.actions

export default userSlice.reducer  