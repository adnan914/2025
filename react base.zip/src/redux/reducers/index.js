import { combineReducers } from 'redux'
import auth from './authReducer'
import layout from "./layoutReducer"
import jsonPlaceholderReducer from './jsonPlaceholderReducer'
import userReducer from './userReducer'

const reducers = combineReducers({
  // layout,
  // auth,
  // jsonPlaceholderReducer,
  // userReducer,
})

export default reducers