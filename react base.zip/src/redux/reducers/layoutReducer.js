import actionType from '../action/layoutAction/actionType'

// const initialState = {
//     // isSideBar: false,
//     // isToggleSideBar: false
// }

// const layoutReducers = (state = initialState, action) => {
//     switch (action.type) {
//         case actionType.TOGGLE_SIDEBAR: return (
//             {...state, isToggleSideBar: action.payload}
//         )
//         default: return state
//     }
// }
  
const layoutReducers = () => {
    
}
export default layoutReducers