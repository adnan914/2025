import actionType from "../action/Users/actionType";

const initialState = {
  userList: [],
  count: 10,
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionType.GET_USER:
      return { ...state, userList: action.payload.users };
    default:
      return state;
  }
};

export default userReducer;
