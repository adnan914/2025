import actionType from '../action/jsonPlaceholderAction/actionType'

const initialState = {
    photosList: [],
    count: 10
}
  
const jsonPlaceholderReducer = (state = initialState, action) => {
    switch (action.type) {
        case actionType.PHOTOS: 
        return (
            {...state, photosList: action.payload}
        )
        default: return state
    }
}
  
export default jsonPlaceholderReducer