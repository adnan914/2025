import axios from '../utils/axiosConfig'
import { API_ROUTES } from 'utils/constant'

export const getPhotos = (params) => axios.get(API_ROUTES.PHOTOS_API, { params })
