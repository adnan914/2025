import axios from 'utils/axiosConfig'
import { API_ROUTES } from 'utils/constant'

export const getUser = () => axios.get("/users")
