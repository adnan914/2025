import React from 'react';
import ReactDOM from 'react-dom/client';
import reportWebVitals from './reportWebVitals';
import './assets/styles/style.scss';
import "toastr/toastr.scss";
import Main from './router';
import axios from './utils/axiosConfig';
import authInterceptor from './utils/axiosConfig/interceptors/authInterceptor';
import tokenInterceptor from './utils/axiosConfig/interceptors/tokenInterceptor';
import errorHandler from './utils/axiosConfig/interceptors/errorHandler';

axios.interceptors.request.use(authInterceptor, error => Promise.reject(error));
axios.interceptors.response.use(tokenInterceptor, error => errorHandler(error));

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Main />
  </React.StrictMode>
);

reportWebVitals();
