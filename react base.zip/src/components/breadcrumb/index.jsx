import { Link } from "react-router-dom"

const Breadcrumb = ({ heading, items }) => {
    return (
        <div className="breadcrumb">
            <h2>{heading}</h2>
            <ul>
                {items.map((e, i) => 
                    <li key={i} className={!e.link ? "active" : ""}>
                        { e.link ? <Link to={e.link}>{e.text}</Link> : e.text }
                    </li>
                )}
            </ul>
        </div>
    )
}

export default Breadcrumb