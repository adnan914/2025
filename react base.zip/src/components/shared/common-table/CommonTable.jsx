import React, { useState, useEffect } from 'react'
import Pagination from '@mui/material/Pagination';
import classes from './styles.module.scss'
import { count } from 'utils/CommonService'
import FilterBy from './FilterBy'
import Button from '@mui/material/Button';
import HideField from './HideField'
import Search from './Search'
import DateRangePicker from 'react-bootstrap-daterangepicker';
import 'bootstrap-daterangepicker/daterangepicker.css';
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined';

const CommonTable = ({ totalCount, customPagination, setCustomPagination, data, keys, filterBy, setFilterBy, AddButton, handleAdd, searchFilter, setSearchFilter, isHideField }) => {
  const arrayToObj = keys.map(e => ({[e.props ? e.props.title : e]: true}))
  const newKeys = Object.assign({}, ...arrayToObj)
  
  const [ keyValue, setKeyValue ] = useState(newKeys)
  const [ dateVal, setDateVal ] = useState("21 April")

  const setPage = (_, value) => {
    setCustomPagination(value)
  }
  const [isLoaded, setLoaded] = useState(false)
  useEffect(() => {
    if(!isLoaded && !totalCount) setLoaded(true)
  }, [isLoaded, totalCount])

  const handleScroll = (e) => {
    if (e.target.scrollLeft > 10) {
      e.target.classList.add('table-left-scrolling')
    } else {
      e.target.classList.remove('table-left-scrolling')
    }
    if (e.target.scrollTop > 10) {
      e.target.classList.add('table-top-scrolling')
    } else {
      e.target.classList.remove('table-top-scrolling')
    }
  }

  const handleChecked = (e, keyName) => {
    setKeyValue({...keyValue, [keyName]: e.target.checked})
  }

  const onApply = (_, moment) => {
    setDateVal(moment.startDate.format('DD MMMM'))
  }
  
  return (
    <>
      <div className={classes.filter}>
        <div>
          <h2>All Applicants</h2>
        </div>
        <div className={classes.filter_left}>
          {typeof searchFilter === "string" ? 
            <Search searchFilter={searchFilter} setSearchFilter={setSearchFilter} />
          : null }
          <DateRangePicker
            initialSettings={{ 
              startDate: '4/21/2022', 
              endDate: '5/20/2022'
            }}
            onApply={onApply}
          >
            <Button variant="outlined" className={classes.filter_btn + " " + classes.margn} startIcon={<CalendarTodayOutlinedIcon />}>{dateVal}</Button>
          </DateRangePicker>
          {isHideField ? <HideField keys={keys} handleChecked={handleChecked} keyValue={keyValue} />  : null}
          {filterBy ? <FilterBy filterBy={filterBy} setFilterBy={setFilterBy} customPagination={customPagination} /> : null }
          {AddButton ? 
            <Button className={classes.add_btn} variant="outlined" onClick={handleAdd}>
              {AddButton}
            </Button>
          : null}
        </div>
      </div>
      <div className={classes.common_table}>
        <div className={`${classes.table} table-responsive scroll`} onScroll={handleScroll}>
          <table>
            <thead>
              <tr>
                {keys.filter(e => keyValue[e.props ? e.props.title : e] ).map((key, index) => 
                  <th key={index}>{key}</th>
                )}
              </tr>
            </thead>
            <tbody>
              {data.map((column, index) => 
                <tr key={index} className={classes.hover_tr}>
                  {Object.keys(column).filter(e => keyValue[e.props ? e.props.title : e]).map((key, i) => (
                    <td className="align-middle" key={i}>{column[key]}</td>
                  ))}
                </tr>
              )}
              {isLoaded ? (
                <tr className="text-center">
                  <td colSpan={keys.length}>No record available</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
        <div className={classes.pagination}>
          <div className={classes.bt_bottom_add_row}>
            <div className={classes.record}>
              <Pagination 
                count={count(totalCount, customPagination?.limit)} 
                color="primary" 
                page={customPagination?.page}
                onChange={setPage}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default CommonTable