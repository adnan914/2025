import { useState, useEffect, useRef, useCallback } from 'react'
import classes from './styles.module.scss'
// import classes from './style.module.scss'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const Sorting = ({ titleIcon, title, setSorting, sortList, sortBy }) => {
    const wrapperRef = useRef(null);
    const [ isActive, setIsActive ] = useState(false)

    const handleDrop = () => {
        setIsActive(!isActive)
    }

    const handleSorting = useCallback((order, sortBy) => {
        setSorting(order, sortBy)
        setIsActive(false)
    },[setSorting])
    

    useEffect(() => {
        function handleClickOutside(event) {
          if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
            setIsActive(false)
          }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
          document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [wrapperRef]);

    return (
        <div className={classes.sorting}>
            <div className={classes.title}>
                <span className={classes.titleName}>{titleIcon} {title}</span>
                {sortList ? 
                <span className={classes.dropdown}>
                    <div ref={wrapperRef}>
                        <KeyboardArrowDownIcon onClick={handleDrop} />
                        <ul className={isActive ? classes.active : ''}>
                            {sortList.map((item, i) => (
                                <li key={i} onClick={() => handleSorting(item.order, sortBy)}>{item.icon} {item.text}</li>
                            ))}
                        </ul>
                    </div>
                </span>
                : null}
            </div>
        </div>
    )
}

export default Sorting