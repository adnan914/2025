import { useState, useEffect, useRef, useCallback } from 'react'
import classes from './styles.module.scss'
// import classes from './style.module.scss'
import Button from '@mui/material/Button';
import FilterListIcon from '@mui/icons-material/FilterList';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

const FilterBy = ({ filterBy, setFilterBy, customPagination }) => {
    const wrapperRef = useRef(null);
    const [ isActive, setIsActive ] = useState(false)

    const handleDrop = () => {
        setIsActive(!isActive)
    }

    const handleFilter = useCallback((value) => {
        setFilterBy(value)
        setIsActive(false)
    },[setFilterBy])
    

    useEffect(() => {
        function handleClickOutside(event) {
          if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
            setIsActive(false)
          }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
          document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [wrapperRef]);

    return (
        <div className={`${classes.sorting} ${classes.margn}`}>
            <div className={classes.title}>
                <span className={classes.dropdown}>
                    <div ref={wrapperRef}>
                        <Button className={classes.filter_btn} variant="outlined" startIcon={<FilterListIcon />} onClick={handleDrop}>
                            {customPagination.filterBy ? `Filter by ${customPagination.filterBy}` : "Filters" }
                        </Button>
                        <ul className={isActive ? classes.active : ''} style={{height: isActive ? (filterBy.length*31) + 10 : 0}}>
                            {filterBy.map((item, i) => (
                                <li className={customPagination.filterBy === item.value ? classes.active_filter : ''} key={i} onClick={() => handleFilter(item.value)}>
                                    {item.text} {customPagination.filterBy === item.value ? <CheckCircleOutlineIcon /> : null}
                                </li>
                            ))}
                        </ul>
                    </div>
                </span>
            </div>
        </div>
    )
}

export default FilterBy