import { useState, useEffect, useRef } from 'react'
import classes from './styles.module.scss'
import Button from '@mui/material/Button';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOffOutlined';
import ContactSupportIcon from '@mui/icons-material/ContactSupport';
import Switch from '@mui/material/Switch';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

const HideField = ({ keys, handleChecked, keyValue }) => {
    
    const wrapperRef = useRef(null);
    const [ isActive, setIsActive ] = useState(false)
    const [ field, setField ] = useState("")

    const handleDrop = () => {
        setIsActive(!isActive)
    }

    useEffect(() => {
        function handleClickOutside(event) {
          if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
            setIsActive(false)
          }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
          document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [wrapperRef]);

    return (
        <div className={`${classes.sorting} ${classes.margn}`}>
            <div className={classes.title}>
                <span className={classes.dropdown}>
                    <div ref={wrapperRef}>
                        <Button className={classes.filter_btn} variant="outlined" startIcon={<VisibilityOffIcon />} onClick={handleDrop}>
                            Hide Field <span className={classes.field_count}>{keys.filter(e => keyValue[e.props ? e.props.title : e] ).length}</span>
                        </Button>
                        <ul className={isActive ? classes.active : ''} style={{height: isActive ? (keys.length*34) + 100 : 0, width: 320}}>
                            <div className={classes.hide_field}>
                                <div className={classes.find_field}>
                                    <input type="text" placeholder='Find a field' onChange={(e) => setField(e.target.value)} value={field} />
                                    <ContactSupportIcon />
                                </div>
                                <FormGroup>
                                    {keys.filter((e) => e.props ? e.props.title.toLowerCase().startsWith(field) : e.toLowerCase().startsWith(field)).map((item, i) => (
                                        <FormControlLabel key={i} control={<Switch defaultChecked size="small" />} label={item} onClick={(e) => handleChecked(e, item.props ? item.props.title : item)} />
                                    ))}
                                </FormGroup>
                            </div>
                        </ul>
                    </div>
                </span>
            </div>
        </div>
    )
}

export default HideField