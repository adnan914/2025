import { Search } from '@mui/icons-material'
import classes from './styles.module.scss'
// import classes from './style.module.scss'

const Searching = ({searchFilter, setSearchFilter}) => {
    return (
        <form className={classes.search_filter}>
          <Search />
          <input type="text" placeholder='Search here' value={searchFilter} onChange={(e) => setSearchFilter(e.target.value)} />
        </form>
    )
}

export default Searching