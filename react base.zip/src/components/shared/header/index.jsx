import React, { useState } from 'react'
import { setLayout } from 'redux/action'
import { isDialogOpen } from 'utils/CommonService'
import { useDispatch, useSelector } from 'react-redux'
import logo from "assets/images/icons/logo.png"
import menuToggle from "assets/images/icons/menu-toggle.svg"
import { Link } from 'react-router-dom'
import bellIcon from "assets/images/icons/bell-icon.png"
import queMark from "assets/images/icons/que-mark.png"
import { ROUTES } from 'utils/constant'

const Header = () => {

    const [isDropDown, setIsDropDown] = useState("")

    const dispatch = useDispatch()

    const handleConfirm = () => {
        isDialogOpen.onNext({
          open: true,
          data: {
            message: "Are you sure you want to logout?",
            title: "Confirmation"
          },
          cancelText: "Cancel",
          confirmText: "Okay",
          onCancel: () => isDialogOpen.onNext(false),
          onConfirm: () => {
            isDialogOpen.onNext(false)
            // dispatch(logout())
          }
        });
    }

    const handleToggle = () => {
        // dispatch(setLayout(!isToggleSideBar))
    }

    return (
        <div className="bt_inner_header">
            <div className="bt_inner_header_logo">
                <img src={logo} alt="logo" />
                <button className="toggle-sidebar" type="button" onClick={handleToggle}>
                    <img src={menuToggle} alt="toggle-icon"/>
                </button>
                <nav className="navbar navbar-expand-md">
                    <div className="collapse navbar-collapse outside_hidden" id="navbarSupportedContent">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Dashboard</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Reports</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={ROUTES.DASHBOARD_PATH} className="nav-link active">Applicants</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Interviews</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={ROUTES.USER_PATH} className="nav-link">Users</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={ROUTES.DEBOUNCE_PATH} className="nav-link">Debounce</Link>
                            </li>
                        </ul>
                    </div>   
                </nav> 
            </div>

            <div className="bt_inner_header_contact">
                <div className="bt_mobile_toggle">
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <img src={menuToggle} alt="toggle-icon"/>
                    </button>
                </div>
                <div className="bt_header_profile_wrapper">
                    <span onClick={() => setIsDropDown(!isDropDown ? "show" : "" )}>
                        <div className="bt_header_profile_img">
                            <span>R</span>
                        </div>
                        <div className="bt_header_profile_cont">
                            <h6>Raj, Sanghvi</h6>
                        </div>
                    </span>
                    <div id="header-dropdown" className={`bt_profile_dropdown collapse outside_hidden ${isDropDown}`}>
                        <ul>
                            <li><Link to="/">My account</Link></li>
                            <li><Link to="/" onClick={handleConfirm}>Log out</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="bt_noti_icon">
                    <Link to="/">
                        <img src={bellIcon} alt="noti-icon"/>
                    </Link>
                </div>
                <div className="bt_noti_icon">
                    <Link to="/">
                        <img src={queMark} alt="noti-icon"/>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default Header