export enum TokenType {
  REFRESH = "REFRESH"
}