import { Request, Response } from 'express';
import bcryptjs from 'bcryptjs';
import UserModel from '../models/users.model';
import { ResMessageUtil, CommonUtils } from '../utils';

class AuthController {
    // Create a new user
    public async createUser(req: Request, res: Response): Promise<void> {
        try {
            const isEmailExist = await UserModel.findOne({ email: req.body.email });
            if (isEmailExist) {
                res.status(409).json({ success: false, message: ResMessageUtil.EMAIL_EXIST });
                return;
            }
            req.body.password = await bcryptjs.hash(req.body.password, 10);

            const userDetails = await UserModel.create(req.body);
            res.status(201).json({ success: true, message: ResMessageUtil.USER_CREATE, data: userDetails });
        } catch (error: any) {
            res.status(500).json({ success: false, message: ResMessageUtil.SERVER_ERROR, error: error.message });
        }
    }

    // User login
    public async loginUser(req: Request, res: Response): Promise<void> {
        try {
            const isEmailExist = await UserModel.findOne({ email: req.body.email }).select('+password');

            if (!isEmailExist) {
                res.status(401).json({ success: false, message: ResMessageUtil.INVALID_CRED });
                return;
            }
            const { password } = isEmailExist;

            const isPasswordMatch = await bcryptjs.compare(req.body.password, password);

            if (!isPasswordMatch) {
                res.status(401).json({ success: false, message: ResMessageUtil.INVALID_CRED });
            }
            const { _id, username, email, phone } = isEmailExist.toJSON();

            // Generate JWT token and refresh token
            const token = CommonUtils.generateToken({ _id, username, email, phone }, process.env.JWT_SECRET as string, { expiresIn: process.env.JWT_EXPIRATION });
            const refreshToken = CommonUtils.generateToken({ _id, username, email, phone }, process.env.JWT_REFRESH_SECRET as string, { expiresIn: process.env.JWT_REFRESH_EXPIRATION });

            res.status(200).json({ success: true, message: ResMessageUtil.LOGIN, data: { _id, username, email, phone, token, refreshToken } });
        } catch (error: any) {
            console.error(error);
            res.status(500).json({ success: false, message: ResMessageUtil.LOGIN_FAILED, error: error.message });
        }
    }

    public async refreshToken(req: Request, res: Response): Promise<void> {
        // Generate JWT token and refresh token
        try {
            const isExist = await UserModel.findOne({ email: req.userData?.email });
            if (!isExist) {
                res.status(401).json({ success: false, message: ResMessageUtil.INVALID_TOKEN });
                return;
            }
            const { _id, username, email, phone } = isExist.toJSON();

            const token = CommonUtils.generateToken({ _id, username, email, phone }, process.env.JWT_SECRET as string, { expiresIn: process.env.JWT_EXPIRATION });
            const refreshToken = CommonUtils.generateToken({ _id, username, email, phone }, process.env.JWT_REFRESH_SECRET as string, { expiresIn: process.env.JWT_REFRESH_EXPIRATION });
            res.status(200).json({ success: true, message: ResMessageUtil.TOKEN_GENERATED, data: { token, refreshToken } });
        } catch (error: any) {
            console.error(error);
            res.status(500).json({ success: false, message: ResMessageUtil.SOMETHING_WENT_WRONG, error: error.message });
        }
    }
}

export default new AuthController();